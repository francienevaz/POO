package com.empresa;
// import java.util.*;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.exibirMenuPrincipal();
    }
}
